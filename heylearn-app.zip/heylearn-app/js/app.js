/* ---------- helpers ---------- */
const $=s=>document.querySelector(s);
const shuffle=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const esc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;');
function say(t){try{const u=new SpeechSynthesisUtterance(t);u.lang='en-US';u.rate=.85;speechSynthesis.cancel();speechSynthesis.speak(u)}catch(e){}}
function playLines(lines){try{speechSynthesis.cancel();let i=0;const n=()=>{if(i>=lines.length){S.ls.play=false;render(true);return}const u=new SpeechSynthesisUtterance(lines[i].t);u.lang='en-US';u.pitch=lines[i].p;u.rate=.85;u.onend=()=>{i++;n()};speechSynthesis.speak(u)};S.ls.play=true;n()}catch(e){S.ls.play=false}}
function toast(m){const old=$('.toast');if(old)old.remove();const d=document.createElement('div');d.className='toast';d.textContent=m;$('#phone').appendChild(d);setTimeout(()=>d.remove(),2200)}
const isDark=()=>{const t=document.documentElement.dataset.theme;return t==='dark'||(!t&&window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches)};
const lvl=()=>{let k=0;LV.forEach((l,i)=>{if(P.xp>=l.min)k=i});return k};
const lvPct=()=>{const k=lvl();return k>=3?100:Math.round((P.xp-LV[k].min)/(LV[k+1].min-LV[k].min)*100)};
function addXp(n){const b=lvl();P.xp+=n;save();if(lvl()>b)toast('🎉 নতুন লেভেল: '+LV[lvl()].bn)}
function go(s,o={}){if(o.reset)S.stack=[];else if(!o.replace)S.stack.push(S.screen);S.screen=s;render()}
function back(){S.screen=S.stack.pop()||'home';render()}
const mkq=(head,opts,ans,o={})=>{const idx=shuffle(opts.map((x,i)=>i));return Object.assign({head,opts:idx.map(i=>opts[i]),ans:idx.indexOf(ans)},o)};
function vocabQs(list){return list.map((w,i)=>{const set=[w,...shuffle(W.filter(x=>x!==w)).slice(0,3)];const note=`${w.e} ${w.en} = ${w.bn}`;
 return i%2===0?mkq(`<div class="pic">${w.e}</div><p class="sub">এটা ইংরেজিতে কী?</p>`,set.map(x=>x.en),0,{note})
  :mkq(`<p class="bn" style="font-size:42px">${w.bn}</p><p class="sub mt">সঠিক ছবিটি বেছে নাও</p>`,set.map(x=>x.e),0,{note,grid:1})})}
const fillQs=n=>shuffle(FILL).slice(0,n).map(f=>mkq(`<p class="en" style="font-size:22px;font-weight:700">${f[0].replace('___','<u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u>')}</p><p class="sub mt">ফাঁকা জায়গায় কী বসবে?</p>`,f[1],0,{note:f[0].replace('___',f[1][0])}));
function launch(kind,rep){
 const o={replace:!!rep};
 if(kind==='mcq'){S.qz={kind,title:'MCQ',qs:vocabQs(shuffle(W).slice(0,6)),i:0,score:0,picked:null};go('qz',o)}
 else if(kind==='fill'){S.qz={kind,title:'ঘর পূরণ',qs:fillQs(6),i:0,score:0,picked:null};go('qz',o)}
 else if(kind==='daily'){S.qz={kind,title:'ডেইলি চ্যালেঞ্জ',qs:shuffle([...vocabQs(shuffle(W).slice(0,3)),...fillQs(2)]),i:0,score:0,picked:null};go('qz',o)}
 else if(kind==='lesson'){S.qz={kind,title:'অনুশীলন',qs:vocabQs(shuffle(FR)),i:0,score:0,picked:null};go('qz',o)}
 else if(kind==='listenq'){S.qz={kind,title:'শোনার প্রশ্ন',qs:LQ.map(q=>mkq(`<p class="en" style="font-size:20px;font-weight:700">${q[0]}</p>`,q[1],q[2])),i:0,score:0,picked:null};go('qz',o)}
 else if(kind==='gq'){const g=G.find(x=>x.k===S.gt);S.qz={kind,title:g.en,qs:g.q.map(q=>mkq(`<p class="en" style="font-size:21px;font-weight:700">${q[0].replace('___','<u>&nbsp;&nbsp;&nbsp;&nbsp;</u>')}</p>`,q[1],q[2])),i:0,score:0,picked:null};go('qz',o)}
 else if(kind==='match'){const L=shuffle(W).slice(0,5);S.mt={L,R:shuffle(L),sel:null,done:[],bad:null,moves:0};go('match',o)}
 else if(kind==='sent'){S.sm={qs:shuffle(SM),i:0,score:0,tries:0,state:null};smInit();go('sent',o)}
 else if(kind==='flash'){let l=W.filter(w=>!P.learned.includes(w.en));if(l.length<3)l=W.slice();S.fl={list:shuffle(l).slice(0,8),i:0,flip:false,known:0};go('flash',o)}
 S.last=kind;
}
function smInit(){const m=S.sm;const t=m.qs[m.i][0].split(' ');m.pool=shuffle(t.map((w,id)=>({w,id})));m.chosen=[];m.state=null;m.tries=0}
function showRes(kind,score,total,xp){
 addXp(xp);S.res={kind,score,total,xp};go('result',{replace:true});
}
function finishQz(){
 const z=S.qz,n=z.qs.length,sc=z.score;
 const xpMax={mcq:30,fill:30,daily:50,lesson:60,gq:20,listenq:25}[z.kind]||20;
 const xp=Math.round(sc/n*xpMax);
 if(z.kind==='lesson'){addXp(xp);S.lscore=sc;FR.forEach(w=>{if(!P.learned.includes(w.en))P.learned.push(w.en)});save();go('done',{replace:true});return}
 if(z.kind==='gq'&&sc>=Math.ceil(n/2)&&!P.gdone.includes(S.gt))P.gdone.push(S.gt);
 if(z.kind==='listenq'){P.listen=Math.max(P.listen,Math.round(sc/n*100));if(sc>=2)P.flags.listen=1}
 if(z.kind==='mcq'&&sc===n)P.flags.quiz=1;
 if(z.kind==='daily'&&sc>=3)P.flags.daily=1;
 save();showRes(z.kind,sc,n,xp);
}
/* speaking */
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
function finishSpeak(r){S.sp.state='done';S.sp.res=r;P.speak=Math.max(P.speak,r.total);if(r.total>=80)P.flags.speak=1;addXp(5);save();render(true)}
function simSpeak(note){const r=a=>Math.round(a+Math.random()*8);const acc=r(84),pron=r(80),flu=r(86);S.sp.note=note;finishSpeak({acc,pron,flu,total:Math.round(acc*.5+pron*.3+flu*.2)})}
function scoreSpeech(heard,conf){
 const norm=t=>t.toLowerCase().replace(/[^a-z\s]/g,'').split(/\s+/).filter(Boolean);
 const t=norm(SPS[S.sp.i]),h=norm(heard);const m=t.filter(w=>h.includes(w)).length;
 const acc=Math.round(m/t.length*100);const pron=Math.max(0,Math.min(100,Math.round((conf||.85)*100-(acc<100?4:0))));
 const flu=Math.min(100,acc+(acc>50?6:0));S.sp.note=`তুমি বলেছো: "${heard}"`;
 finishSpeak({acc,pron,flu,total:Math.round(acc*.5+pron*.3+flu*.2)});
}
function mic(){
 if(S.sp.state==='listening')return;
 S.sp.state='listening';S.sp.note='';render(true);
 if(!SR){setTimeout(()=>simSpeak('এই ব্রাউজারে মাইক সাপোর্ট নেই, তাই ডেমো স্কোর দেখানো হচ্ছে।'),1800);return}
 try{const r=new SR();r.lang='en-US';r.interimResults=false;
  r.onresult=e=>scoreSpeech(e.results[0][0].transcript,e.results[0][0].confidence);
  r.onerror=()=>{if(S.sp.state==='listening')simSpeak('মাইক চালু করা যায়নি, তাই ডেমো স্কোর দেখানো হচ্ছে।')};
  r.onend=()=>{if(S.sp.state==='listening'){S.sp.state='idle';S.sp.note='কিছু শোনা যায়নি, আবার চেষ্টা করো।';render(true)}};
  r.start()}catch(e){simSpeak('মাইক চালু করা যায়নি, তাই ডেমো স্কোর দেখানো হচ্ছে।')}
}

/* ---------- views ---------- */
const NAVMAP={home:'home',learn:'learn',vocab:'learn',grammar:'learn',practice:'practice',speak:'practice',listen:'practice',progress:'progress',profile:'profile',level:'profile',badges:'profile'};
const ICON={home:'<path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',learn:'<path d="M4 4h12a3 3 0 0 1 3 3v13H7a3 3 0 0 1-3-3z"/><path d="M8 9h7"/>',practice:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/>',progress:'<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',profile:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'};
const TABS=[['home','হোম'],['learn','শিখি'],['practice','অনুশীলন'],['progress','অগ্রগতি'],['profile','প্রোফাইল']];
const nav=a=>`<nav class="nav">${TABS.map(([k,l])=>`<button data-a="tab" data-k="${k}" class="${a===k?'on':''}"><svg viewBox="0 0 24 24">${ICON[k]}</svg>${l}</button>`).join('')}</nav>`;
const head=(t,r='')=>`<div class="hd"><button class="back" data-a="back" aria-label="পিছনে">←</button><h1 class="h2">${t}</h1><div>${r}</div></div>`;
const topbar=(step,pct)=>`<div class="row"><button class="back" data-a="back" aria-label="পিছনে">←</button><div class="bar"><i style="width:${pct}%"></i></div><span class="sub en">${step}</span></div>`;
const chips=(arr,cur,act)=>`<div class="chips">${arr.map(([k,l])=>`<button class="tabc ${cur===k?'on':''}" data-a="${act}" data-k="${k}">${l}</button>`).join('')}</div>`;
const pctOf=(a,b)=>Math.round(a/b*100);
const ring=(p,l,sm)=>`<div class="ring ${sm?'sm':''}" style="--p:${p}"><div><span class="en">${p}%${l?`<small>${l}</small>`:''}</span></div></div>`;

const V={
splash:()=>`<div class="splash"><div class="bubble">Hey</div><h1>HeyLearn</h1><p>ছবি দেখে, শুনে, বলে ইংরেজি শিখি</p><button class="btn" data-a="tab" data-k="home">শুরু করি</button></div>`,

home:()=>{const w=W[new Date().getDate()%W.length];const mk=P.marks.includes(w.en);
 return `<div class="view">
 <div class="row sp"><div><h1 class="h1">শুভ সকাল 👋</h1><p class="sub">আজও একটু একটু করে এগোই</p></div><button class="back" data-a="toast" data-m="আজ কোনো নতুন নোটিফিকেশন নেই" aria-label="নোটিফিকেশন">🔔</button></div>
 <div class="grid2 mt">
  <div class="card"><div class="row"><span style="font-size:26px">🔥</span><div><p class="sub">টানা শেখা</p><p class="h2">৭ দিন</p></div></div><div class="dotw">${[1,1,1,1,1,1,1].map(x=>`<i class="on"></i>`).join('')}</div></div>
  <div class="card row"><div>${ring(lvPct(),'',1)}</div><div><p class="sub">লেভেল প্রগ্রেস</p><p class="sub">${P.xp} XP</p></div></div>
 </div>
 <button class="tile mt" data-a="lesson" style="background:linear-gradient(135deg,#3F7DF5,#6FA3FF);color:#fff">
  <span style="color:#DCE8FF">আজকের পাঠ</span><b style="font-size:21px;margin:2px 0">ফল · Fruits 🍎</b><span style="color:#DCE8FF">৬টি নতুন শব্দ · প্রায় ১০ মিনিট</span>
  <div class="bar mt" style="background:rgba(255,255,255,.3)"><i style="width:${P.flags.lesson?100:15}%;background:#fff"></i></div></button>
 <div class="card mt">
  <div class="row sp"><span class="chip" style="background:var(--yellow-s);color:var(--yellow)">আজকের শব্দ</span><div class="row" style="gap:8px"><button class="mini ${mk?'on':''}" data-a="mark" data-w="${w.en}" aria-label="সেভ">${mk?'★':'☆'}</button><button class="mini" data-a="say" data-t="${w.en}" aria-label="উচ্চারণ">🔊</button></div></div>
  <div class="row mt"><div class="pic2">${w.e}</div><div><p class="word" style="font-size:28px">${w.en}</p><p class="sub en">${w.ip} · ${w.pr}</p><p class="bn2">${w.bn}</p></div></div>
  <p class="en mt">${w.ex}</p></div>
 <div class="grid2 mt">
  <button class="tile c-purple" data-a="go" data-s="vocab"><div class="ico" style="background:var(--card)">📚</div><b class="mt">শব্দভান্ডার</b><span>নতুন শব্দ শিখি</span></button>
  <button class="tile c-green" data-a="go" data-s="grammar"><div class="ico" style="background:var(--card)">✏️</div><b class="mt">ব্যাকরণ</b><span>ভিত্তি মজবুত করি</span></button>
  <button class="tile c-yellow" data-a="go" data-s="speak"><div class="ico" style="background:var(--card)">🎙️</div><b class="mt">স্পিকিং</b><span>জোরে বলে দেখি</span></button>
  <button class="tile c-blue" data-a="go" data-s="listen"><div class="ico" style="background:var(--card)">🎧</div><b class="mt">লিসেনিং</b><span>শুনে উত্তর দিই</span></button>
 </div>
 <button class="tile c-yellow mt" data-a="daily"><div class="row"><div class="ico" style="background:var(--card)">🏆</div><div style="flex:1"><b>ডেইলি চ্যালেঞ্জ</b><span>৫টি প্রশ্ন · +৫০ XP পর্যন্ত</span></div><span>›</span></div></button>
 <div class="card mt row" style="opacity:.8"><div class="ico c-purple">🤖</div><div><b>AI টিউটর</b><p class="sub">শীঘ্রই আসছে — প্রশ্ন করলেই বাংলায় বুঝিয়ে দেবে</p></div></div>
 </div>${nav('home')}`},

learn:()=>`<div class="view"><h1 class="h1">শিখি</h1><p class="sub">যেখান থেকে খুশি শুরু করো</p>
 <button class="tile mt c-blue" data-a="lesson"><div class="row"><div class="ico" style="background:var(--card)">🍎</div><div style="flex:1"><b>ফল · Fruits</b><span>ছবি → শব্দ → অনুশীলন → গল্প → লেখা</span></div><span>›</span></div></button>
 <h2 class="h2 mt2">শেখার ক্ষেত্র</h2>
 <div class="grid2 mt">${[['📚','শব্দভান্ডার','Vocabulary','vocab','purple'],['✏️','ব্যাকরণ','Grammar','grammar','green'],['🎧','শোনা','Listening','listen','blue'],['🎙️','বলা','Speaking','speak','yellow'],['📖','গল্প','Story','story','purple'],['✍️','লেখা','Writing','writing','green']].map(t=>`
  <button class="tile c-${t[4]}" data-a="go" data-s="${t[3]}"><div class="ico" style="background:var(--card)">${t[0]}</div><b class="mt">${t[1]}</b><span class="en">${t[2]}</span></button>`).join('')}</div>
 <h2 class="h2 mt2">সব পাঠ</h2>
 ${UNITS.map((u,i)=>`<button class="card mt" ${i?'':'data-a="lesson"'} style="width:100%;border:0;text-align:left;font:inherit;color:var(--ink);opacity:${i?.55:1};cursor:${i?'default':'pointer'}"><div class="row"><div class="ico c-${u[4]}">${u[0]}</div><div style="flex:1"><b>${u[1]} <span class="en sub">· ${u[2]}</span></b><p class="sub">${u[3]}</p></div><span>${i?'🔒':(P.flags.lesson?'✅':'›')}</span></div></button>`).join('')}
 </div>${nav('learn')}`,

vocab:()=>{const f=S.vf;const l=W.filter(w=>f==='all'||(f==='learned'?P.learned.includes(w.en):!P.learned.includes(w.en)));
 return `<div class="view">${head('শব্দভান্ডার','<button class="back" data-a="search-focus" aria-label="খুঁজি">🔍</button>')}
 ${chips([['all','সব'],['learned','শেখা'],['todo','শিখতে হবে'],['saved','সেভ করা']],f,'vf')}
 <input id="vs" class="search" placeholder="শব্দ খোঁজো…" aria-label="শব্দ খোঁজো">
 ${(f==='saved'?W.filter(w=>P.marks.includes(w.en)):l).map(w=>{const mk=P.marks.includes(w.en);return `<div class="card vcard mt" data-w="${w.en} ${w.bn}"><div class="row" style="align-items:flex-start">
  <div style="flex:1"><div class="row" style="gap:8px"><b class="en" style="font-size:20px">${w.en}</b><button class="mini" data-a="say" data-t="${w.en}" aria-label="উচ্চারণ">🔊</button></div>
  <p class="sub en">${w.ip} · ${w.pr}</p><p class="bn2">${w.bn}</p><p class="en mt" style="font-size:15px">${w.ex}</p><p class="sub">${w.exb}</p>
  ${P.learned.includes(w.en)?'<span class="chip c-green" style="color:var(--green);margin-top:8px">✓ শেখা</span>':''}</div>
  <div style="display:flex;flex-direction:column;gap:8px;align-items:center"><div class="pic2">${w.e}</div><button class="mini ${mk?'on':''}" data-a="mark" data-w="${w.en}" aria-label="সেভ">${mk?'★':'☆'}</button></div></div></div>`}).join('')||`<div class="card mt" style="text-align:center"><p class="sub">এখানে এখনো কিছু নেই।</p></div>`}
 <div class="stick"><button class="btn" data-a="flash">⚡ ফ্ল্যাশকার্ড মোড</button></div></div>${nav('learn')}`},

flash:()=>{const z=S.fl,w=z.list[z.i];
 return `<div class="view">${topbar(`${z.i+1}/${z.list.length}`,(z.i)/z.list.length*100)}
 <button class="card flash mt2" data-a="flip" style="width:100%;border:0;font:inherit;color:var(--ink);min-height:300px;cursor:pointer">
 ${z.flip?`<p class="bn" style="font-size:40px">${w.bn}</p><p class="sub en mt">${w.ip} · ${w.pr}</p><div class="ex"><p class="en">${w.ex}</p><p class="sub">${w.exb}</p></div><p class="sub mt">আবার ট্যাপ করলে ছবিতে ফিরবে</p>`
  :`<div class="pic">${w.e}</div><p class="word">${w.en}</p><p class="sub mt">অর্থ দেখতে কার্ডে ট্যাপ করো</p>`}</button>
 <div class="stick"><div class="row"><button class="spk" data-a="say" data-t="${w.en}" aria-label="উচ্চারণ">🔊</button><button class="btn ghost" data-a="flno" style="flex:1">আবার দেখব</button><button class="btn green" data-a="flyes" style="flex:1">জানি ✓</button></div></div></div>`},

grammar:()=>`<div class="view">${head('ব্যাকরণ')}
 <div class="grid2">${G.map(g=>`<button class="tile c-${g.col}" data-a="gtopic" data-k="${g.k}"><div class="ico" style="background:var(--card)">${g.e}</div><b class="mt en">${g.en}</b><span>${g.bn}${P.gdone.includes(g.k)?' · ✅':''}</span></button>`).join('')}</div>
 <div class="card mt row"><div class="ico c-green">📘</div><div style="flex:1"><b>শেখা হয়েছে ${P.gdone.length}/${G.length}</b><div class="bar mt" style="margin-top:8px"><i style="width:${pctOf(P.gdone.length,G.length)}%;background:var(--green)"></i></div></div></div>
 </div>${nav('learn')}`,

gtopic:()=>{const g=G.find(x=>x.k===S.gt);
 return `<div class="view">${head(`${g.en} · ${g.bn}`)}
 <div class="card"><span class="chip c-${g.col}">${g.sub}</span><p class="mt">${g.rule}</p><div class="formula">${g.f}</div></div>
 <h2 class="h2 mt2">উদাহরণ</h2>
 ${g.ex.map(x=>`<div class="card mt row"><div style="flex:1"><p class="en" style="font-size:18px;font-weight:700">${x[0]}</p><p class="sub">${x[1]}</p></div><button class="mini" data-a="say" data-t="${esc(x[0].replace(/"/g,''))}" aria-label="শুনি">🔊</button></div>`).join('')}
 <div class="stick"><button class="btn" data-a="gprac">অনুশীলন করি</button></div></div>`},

practice:()=>{const f=S.gf;const T=[['mcq','❓','MCQ','জ্ঞান যাচাই করো','blue'],['fill','✏️','ঘর পূরণ','বাক্য সম্পূর্ণ করো','yellow'],['match','🧩','শব্দ মেলানো','ইংরেজি ↔ বাংলা','green'],['sent','🔤','বাক্য গঠন','শব্দ সাজিয়ে বাক্য বানাও','purple']];
 const show=T.filter(t=>f==='all'||f===t[0]);
 return `<div class="view"><h1 class="h1">কুইজ ও গেমস</h1><p class="sub">খেলতে খেলতে শিখি</p>
 ${chips([['all','সব'],['mcq','MCQ'],['fill','ঘর পূরণ'],['match','মেলানো'],['sent','বাক্য']],f,'gf')}
 <div class="grid2">${show.map(t=>`<button class="tile c-${t[4]}" data-a="${t[0]==='mcq'?'mcq':t[0]==='fill'?'fill':t[0]==='match'?'match':'sent'}"><div class="ico" style="background:var(--card)">${t[1]}</div><b class="mt">${t[2]}</b><span>${t[3]}</span></button>`).join('')}</div>
 <button class="tile c-yellow mt" data-a="daily"><div class="row"><div class="ico" style="background:var(--card)">🏆</div><div style="flex:1"><b>ডেইলি চ্যালেঞ্জ</b><span>আজকের চ্যালেঞ্জ শেষ করে পুরস্কার জিতো</span></div><span>${P.flags.daily?'✅':'›'}</span></div></button>
 ${f==='all'?`<h2 class="h2 mt2">দক্ষতা অনুশীলন</h2><div class="grid2 mt">
  <button class="tile c-blue" data-a="go" data-s="listen"><div class="ico" style="background:var(--card)">🎧</div><b class="mt">লিসেনিং</b><span>কথোপকথন শুনি</span></button>
  <button class="tile c-green" data-a="go" data-s="speak"><div class="ico" style="background:var(--card)">🎙️</div><b class="mt">স্পিকিং</b><span>বলে স্কোর পাই</span></button></div>`:''}
 </div>${nav('practice')}`},

qz:()=>{const z=S.qz,q=z.qs[z.i],p=z.picked;const cls=i=>p===null?'':(i===q.ans?'ok':(i===p?'no':''));
 const body=q.grid?`<div class="eopts mt">${q.opts.map((o,i)=>`<button class="opt ${cls(i)}" data-a="pick" data-i="${i}" ${p!==null?'disabled':''}>${o}</button>`).join('')}</div>`
  :q.opts.map((o,i)=>`<button class="opt ${cls(i)}" data-a="pick" data-i="${i}" ${p!==null?'disabled':''}><span class="lt">${'ABCD'[i]}</span><span>${o}</span></button>`).join('');
 const ok=p===q.ans;
 return `<div class="view">${topbar(`${z.i+1}/${z.qs.length}`,(z.i+(p!==null?1:0))/z.qs.length*100)}
 <div class="card flash mt2">${q.head}</div>${body}
 ${p!==null?`<div class="card mt row" style="background:${ok?'var(--green-s)':'var(--red-s)'}"><span style="font-size:26px">${ok?'🎉':'💡'}</span><div><b>${ok?'দারুণ, ঠিক হয়েছে!':'আরেকটু হলেই হতো'}</b><p class="sub en">${q.note||''}</p></div></div><div class="stick"><button class="btn" data-a="nextq">${z.i<z.qs.length-1?'পরের প্রশ্ন':'ফলাফল দেখি'}</button></div>`:''}</div>`},

match:()=>{const m=S.mt;
 return `<div class="view">${topbar(`${m.done.length}/5`,m.done.length/5*100)}
 <h1 class="h2 mt2">শব্দ মেলাও</h1><p class="sub">বাঁ দিকের ইংরেজি শব্দ ধরে ডান দিকের বাংলা অর্থ বেছে নাও</p>
 <div class="grid2 mt"><div>${m.L.map((w,i)=>`<button class="opt en ${m.done.includes(w.en)?'ok':(m.sel===i?'sel':(m.bad&&m.bad[0]===i?'no':''))}" data-a="ml" data-i="${i}" ${m.done.includes(w.en)?'disabled':''}>${w.e} ${w.en}</button>`).join('')}</div>
 <div>${m.R.map((w,j)=>`<button class="opt ${m.done.includes(w.en)?'ok':(m.bad&&m.bad[1]===j?'no':'')}" data-a="mr" data-j="${j}" ${m.done.includes(w.en)?'disabled':''}>${w.bn}</button>`).join('')}</div></div></div>`},

sent:()=>{const m=S.sm,q=m.qs[m.i];const ch=m.chosen.map(id=>m.pool.find(x=>x.id===id));const rest=m.pool.filter(x=>!m.chosen.includes(x.id));
 return `<div class="view">${topbar(`${m.i+1}/${m.qs.length}`,m.i/m.qs.length*100)}
 <h1 class="h2 mt2">বাক্যটি সাজাও</h1><div class="card mt"><p class="bn2">${q[1]}</p></div>
 <div class="slot mt ${m.state||''}">${ch.map(x=>`<button class="wd" data-a="smdel" data-id="${x.id}" ${m.state==='ok'?'disabled':''}>${x.w}</button>`).join('')}</div>
 <div class="mt">${rest.map(x=>`<button class="wd" data-a="smadd" data-id="${x.id}" ${m.state==='ok'?'disabled':''}>${x.w}</button>`).join('')}</div>
 ${m.state==='bad'?`<p class="mt" style="color:var(--red)">এখনো ঠিক হয়নি — শব্দের ক্রম আবার দেখো।</p>`:''}
 ${m.state==='ok'?`<p class="mt" style="color:var(--green)"><b>সুন্দর! 🎉</b></p><div class="stick"><button class="btn" data-a="smnext">${m.i<m.qs.length-1?'পরের বাক্য':'ফলাফল দেখি'}</button></div>`
  :`<div class="stick"><button class="btn" data-a="smchk" ${ch.length?'':'disabled'}>চেক করি</button></div>`}</div>`},

result:()=>{const r=S.res,ratio=r.score/r.total;const t=ratio>=.8?'দারুণ করেছো!':ratio>=.5?'ভালো চেষ্টা!':'আরেকবার চেষ্টা করি!';
 return `<div class="view" style="text-align:center"><div class="confetti mt2">${ratio>=.5?'🎉':'💪'}</div><h1 class="h1 mt">${t}</h1>
 <div class="stars mt">${ratio>=.8?'⭐⭐⭐':ratio>=.5?'⭐⭐☆':'⭐☆☆'}</div>
 <div class="grid2 mt2"><div class="card"><p class="sub">স্কোর</p><p class="h2 en">${r.score}/${r.total}</p></div><div class="card"><p class="sub">অর্জিত XP</p><p class="h2 en">+${r.xp}</p></div></div>
 <div class="stick"><button class="btn" data-a="again">আবার করি</button><button class="btn ghost mt" data-a="back">ঠিক আছে</button></div></div>`},

lesson:()=>`<div class="view">${head('ফল · Fruits')}
 <div class="card flash"><div class="pic" style="font-size:72px">🍎🍌🥭</div><p class="sub">প্রতিদিনের পরিচিত ফলের নাম ইংরেজিতে</p></div>
 <h2 class="h2 mt2">এই পাঠে যা যা থাকছে</h2>
 ${[['🖼️','ছবি দেখে শব্দ শেখা','৬টি কার্ড','blue'],['🎯','অনুশীলন','৬টি প্রশ্ন','green'],['📖','ছোট গল্প','শুনি ও পড়ি','yellow'],['✍️','নিজে লিখি','১–২টি বাক্য','purple']].map(s=>`
 <div class="card mt row"><div class="ico c-${s[3]}">${s[0]}</div><div><b>${s[1]}</b><p class="sub">${s[2]}</p></div></div>`).join('')}
 <div class="stick"><button class="btn" data-a="startvocab">পাঠ শুরু করি</button></div></div>`,

vcard:()=>{const w=FR[S.wi];return `<div class="view">${topbar(`${S.wi+1}/6`,(S.wi+1)/6*40)}
 <div class="card flash mt2"><div class="pic">${w.e}</div>
  <div class="row" style="justify-content:center"><span class="word">${w.en}</span><button class="spk" data-a="say" data-t="${w.en}" aria-label="উচ্চারণ শুনি">🔊</button></div>
  <p class="sub en">${w.ip} · ${w.pr}</p><p class="bn mt">${w.bn}</p>
  <div class="ex"><p class="en" style="font-size:18px">${w.ex}</p><p class="sub">${w.exb}</p><button class="spk mt" style="width:auto;padding:0 14px;border-radius:99px;font-size:14px" data-a="say" data-t="${w.ex}">🔊 বাক্যটি শুনি</button></div></div>
 <div class="dots">${FR.map((_,i)=>`<i class="${i===S.wi?'on':''}"></i>`).join('')}</div>
 <div class="stick"><div class="row"><button class="btn ghost" data-a="vprev" ${S.wi?'':'disabled'} style="flex:1">আগের</button><button class="btn" data-a="vnext" style="flex:2">${S.wi<5?'পরের শব্দ':'অনুশীলনে যাই'}</button></div></div></div>`},

done:()=>`<div class="view" style="text-align:center"><div class="confetti mt2">🎉</div><h1 class="h1 mt">পাঠ শেষ! অভিনন্দন</h1><p class="sub">তুমি ৬টি নতুন শব্দ শিখলে</p>
 <div class="stars mt">${S.lscore>=5?'⭐⭐⭐':S.lscore>=3?'⭐⭐☆':'⭐☆☆'}</div>
 <div class="grid2 mt2"><div class="card"><p class="sub">সঠিক উত্তর</p><p class="h2 en">${S.lscore}/6</p></div><div class="card"><p class="sub">মোট XP</p><p class="h2 en">${P.xp}</p></div></div>
 <div class="card mt" style="background:var(--yellow-s);text-align:left"><b>এবার গল্পে শব্দগুলো দেখি</b><p class="sub">বাক্যের ভেতরে দেখলে শব্দ বেশি দিন মনে থাকে।</p></div>
 <div class="stick"><button class="btn" data-a="story">গল্পটি পড়ি</button><button class="btn ghost mt" data-a="lessonq">আবার অনুশীলন করি</button></div></div>`,

story:()=>{const hl=t=>FR.reduce((s,w)=>s.replace(new RegExp('\\b('+w.en+'s?)\\b','i'),'<b>$1</b>'),t);
 return `<div class="view">${head('গল্প')}<h1 class="h1 en">Rumi and the Mango Tree</h1><p class="sub">বাক্যে ট্যাপ করলে বাংলা অর্থ দেখাবে</p>
 <button class="btn ghost mt" data-a="say" data-t="${STORY.map(s=>s[0]).join(' ')}">🔊 পুরো গল্পটি শুনি</button>
 ${STORY.map((s,i)=>`<div class="sent" data-a="tog" data-i="${i}" role="button" tabindex="0">${hl(s[0])}${S.open[i]?`<em>${s[1]}</em>`:''}</div>`).join('')}
 <div class="stick"><button class="btn" data-a="writing">নিজে লিখি</button></div></div>`},

writing:()=>{const f=S.fb;return `<div class="view">${head('নিজে লিখি ✍️')}<p class="sub">তোমার প্রিয় ফল নিয়ে ইংরেজিতে ১–২টি বাক্য লেখো।</p>
 <div class="card mt c-purple"><p class="sub">সাহায্য</p><p class="en"><b>I like ___ because it is ___.</b></p><p class="sub en">sweet · juicy · yellow · fresh</p></div>
 <textarea id="ta" class="mt" placeholder="এখানে লেখো…" aria-label="তোমার লেখা">${esc(S.text)}</textarea>
 ${f?`<div class="card mt" style="background:${f.good?'var(--green-s)':'var(--yellow-s)'}"><b>${f.title}</b><p class="sub" style="color:var(--ink)">${f.msg}</p></div>`:''}
 <div class="stick"><button class="btn ghost" data-a="check">লেখা দেখি</button><button class="btn green mt" data-a="finish">পাঠ সম্পূর্ণ করি</button></div></div>`},

listen:()=>{const h=[14,22,10,30,18,26,12,32,20,14,28,16,24,10,30,18,22,12,26,16];
 return `<div class="view">${head('লিসেনিং')}
 <div class="card c-blue row"><div class="ico" style="background:var(--card)">🎧</div><p><b>কথোপকথনটি শোনো, তারপর প্রশ্নের উত্তর দাও।</b></p></div>
 <div class="card mt"><div class="row"><button class="spk" style="width:54px;height:54px;background:var(--blue);color:#fff" data-a="playconv" aria-label="চালাই">${S.ls.play?'⏸':'▶'}</button><div class="wave">${h.map(x=>`<i style="height:${x}px"></i>`).join('')}</div></div>
 <button class="btn ghost mt" data-a="showtr">${S.ls.show?'লেখা লুকাই':'লেখা দেখি'}</button>
 ${S.ls.show?CONV.map(c=>`<p class="en mt"><b>${c.n}:</b> ${c.t}</p>`).join(''):''}</div>
 <div class="stick"><button class="btn" data-a="lq">প্রশ্নের উত্তর দিই</button></div></div>${nav('practice')}`},

speak:()=>{const s=S.sp,r=s.res,t=SPS[s.i];
 return `<div class="view">${head('স্পিকিং প্র্যাকটিস')}
 <div class="card c-blue"><p class="sub" style="color:var(--ink)">মাইকে ট্যাপ করে বাক্যটি স্পষ্ট করে বলো।</p></div>
 <div class="card mt flash"><div class="row" style="justify-content:center"><p class="en" style="font-size:25px;font-weight:800">${t}</p><button class="spk" data-a="say" data-t="${t}" aria-label="শুনি">🔊</button></div></div>
 <div style="text-align:center;margin:26px 0 12px"><button class="mic ${s.state==='listening'?'live':''}" data-a="mic" aria-label="বলো">🎙️</button>
 <p class="sub mt">${s.state==='listening'?'শুনছি…':s.state==='done'?'আবার বলতে মাইকে ট্যাপ করো':'ট্যাপ করে বলো'}</p></div>
 ${s.note?`<p class="sub" style="text-align:center">${esc(s.note)}</p>`:''}
 ${r?`<div class="card mt"><div class="row"><div>${ring(r.total,'স্কোর',1)}</div><div style="flex:1">${[['উচ্চারণ',r.pron],['সাবলীলতা',r.flu],['নির্ভুলতা',r.acc]].map(x=>`<div class="row sp sub"><span>${x[0]}</span><b class="en" style="color:var(--green)">${Math.min(100,x[1])}</b></div>`).join('')}</div></div></div>`:''}
 <div class="row mt"><button class="btn ghost" data-a="spagain" style="flex:1">আবার চেষ্টা</button><button class="btn" data-a="spnext" style="flex:1">পরের বাক্য</button></div></div>${nav('practice')}`},

progress:()=>{const f=S.pf,vp=pctOf(P.learned.length,W.length),gp=pctOf(P.gdone.length,G.length);
 const tabs=chips([['overview','সারসংক্ষেপ'],['vocab','শব্দ'],['grammar','ব্যাকরণ']],f,'pf');
 let body='';
 if(f==='overview')body=`<div class="card mt">${ring(lvPct(),LV[lvl()].bn)}<p class="sub" style="text-align:center;margin-top:10px">এগিয়ে চলো, ভালো করছো!</p></div>
  <div class="grid2 mt">${[['📚','শব্দভান্ডার',vp,'purple'],['✏️','ব্যাকরণ',gp,'green'],['🎙️','স্পিকিং',P.speak,'yellow'],['🎧','লিসেনিং',P.listen,'blue']].map(s=>`<div class="card c-${s[3]}" style="box-shadow:none"><div class="row"><span style="font-size:22px">${s[0]}</span><div><p class="sub">${s[1]}</p><p class="h2 en">${s[2]}%</p></div></div></div>`).join('')}</div>
  <div class="card mt"><b>এই সপ্তাহে</b><div class="week">${[['শনি',40],['রবি',60],['সোম',85],['মঙ্গল',30],['বুধ',70],['বৃহ',50],['আজ',Math.min(100,20+Math.round((P.xp-210)/2))]].map(d=>`<div><i style="height:${d[1]}px"></i>${d[0]}</div>`).join('')}</div></div>`;
 else if(f==='vocab')body=`<div class="grid2 mt"><div class="card"><p class="sub">শেখা শব্দ</p><p class="h1 en">${P.learned.length}/${W.length}</p></div><div class="card"><p class="sub">সেভ করা</p><p class="h1 en">${P.marks.length}</p></div></div>
  <div class="card mt"><b>ক্যাটাগরি অনুযায়ী</b>${[['ফল',FR],['সাধারণ শব্দ',W.filter(w=>w.c==='g')]].map(c=>{const n=c[1].filter(w=>P.learned.includes(w.en)).length;return `<div class="skill"><div class="row sp sub"><span>${c[0]}</span><span class="en">${n}/${c[1].length}</span></div><div class="bar"><i style="width:${pctOf(n,c[1].length)}%;background:var(--purple)"></i></div></div>`}).join('')}</div>`;
 else body=`<div class="card mt"><b>বিষয়ভিত্তিক অগ্রগতি</b>${G.map(g=>`<div class="skill"><div class="row sp sub"><span class="en">${g.en}</span><span>${P.gdone.includes(g.k)?'✅ শেষ':'বাকি'}</span></div><div class="bar"><i style="width:${P.gdone.includes(g.k)?100:0}%;background:var(--green)"></i></div></div>`).join('')}</div>`;
 return `<div class="view"><h1 class="h1">অগ্রগতি</h1><p class="sub">ছোট ছোট ধাপ, বড় উন্নতি</p>${tabs}${body}</div>${nav('progress')}`},

level:()=>{const k=lvl();
 return `<div class="view">${head('আমার লেভেল')}
 ${LV.map((l,i)=>`<div class="card mt row" style="${i>k?'opacity:.6':''}"><div class="ico c-${l.col}">${l.ic}</div><div style="flex:1"><b class="en">${l.en} <span class="sub">· ${l.bn}</span></b><p class="sub">${l.d}</p></div><span>${i<k?'✅':i===k?'<span class="chip c-green" style="color:var(--green)">চলমান</span>':'🔒'}</span></div>`).join('')}
 ${k<3?`<div class="card mt c-purple" style="box-shadow:none"><div class="row"><span style="font-size:40px">⛰️</span><div style="flex:1"><b>পরের লেভেল: ${LV[k+1].bn}</b><p class="sub">আর ${LV[k+1].min-P.xp} XP বাকি</p><div class="bar mt" style="margin-top:8px"><i style="width:${lvPct()}%;background:var(--green)"></i></div></div></div></div>`:''}</div>${nav('profile')}`},

badges:()=>{const st={lesson:!!P.flags.lesson,streak:true,words:P.learned.length>=10,quiz:!!P.flags.quiz,speak:!!P.flags.speak,listen:!!P.flags.listen,daily:!!P.flags.daily,gram:P.gdone.length>=3};
 return `<div class="view">${head('অর্জন')}<p class="sub">${BADGES.filter(b=>st[b[3]]).length}/${BADGES.length}টি অর্জন হয়েছে</p>
 <div class="grid2 mt">${BADGES.map(b=>`<div class="card bd ${st[b[3]]?'':'lock'}"><div class="ico c-yellow">${b[0]}</div><b>${b[1]}</b><p class="sub">${b[2]}</p></div>`).join('')}</div></div>${nav('profile')}`},

profile:()=>`<div class="view"><div class="row"><div class="ico" style="width:64px;height:64px;font-size:34px;background:var(--blue-s);border-radius:50%">🙂</div><div><h1 class="h1">শিক্ষার্থী</h1><span class="chip c-green" style="color:var(--green)">${LV[lvl()].ic} ${LV[lvl()].bn} · ${P.xp} XP</span></div></div>
 <div class="card mt list">
  <div class="row sp" data-a="go" data-s="level"><span>🏅 আমার লেভেল</span><span class="sub">›</span></div>
  <div class="row sp" data-a="tab" data-k="progress"><span>📊 আমার অগ্রগতি</span><span class="sub">›</span></div>
  <div class="row sp" data-a="go" data-s="badges"><span>🏆 অর্জন</span><span class="sub">›</span></div>
  <div class="row sp"><span>🌙 ডার্ক মোড</span><button class="toggle ${isDark()?'on':''}" data-a="theme" aria-label="ডার্ক মোড"></button></div>
  <div class="row sp"><span>⏰ প্রতিদিনের রিমাইন্ডার</span><div class="row" style="gap:8px">${P.remind.on?`<input id="rt" class="sel-time" type="time" value="${P.remind.time}" aria-label="সময়">`:''}<button class="toggle ${P.remind.on?'on':''}" data-a="remind" aria-label="রিমাইন্ডার"></button></div></div>
  <div class="row sp" data-a="toast" data-m="HeyLearn-এ যেকোনো সমস্যা হলে আমাদের জানাও"><span>❓ সাহায্য</span><span class="sub">›</span></div>
  <div class="row sp" data-a="toast" data-m="HeyLearn · ডেমো সংস্করণ"><span>ℹ️ অ্যাপ সম্পর্কে</span><span class="sub">›</span></div>
 </div>
 <div class="card mt"><b>দৈনিক লক্ষ্য</b><p class="sub">প্রতিদিন কত মিনিট শিখবে?</p>${chips([[10,'১০ মিনিট'],[15,'১৫ মিনিট'],[20,'২০ মিনিট'],[30,'৩০ মিনিট']],P.goal,'goal')}</div>
 </div>${nav('profile')}`
};

/* ---------- render & events ---------- */
function render(keep){
 const el=$('#app');const y=keep&&$('.view')?$('.view').scrollTop:0;
 el.innerHTML=V[S.screen]();
 const v=el.querySelector('.view');if(v)v.scrollTop=y;
}
function checkWriting(){
 const t=S.text.trim(),n=t.split(/\s+/).filter(Boolean).length;
 const used=FR.filter(w=>t.toLowerCase().includes(w.en)).map(w=>w.en);
 if(n<4){S.fb={good:false,title:'আরেকটু লেখো',msg:'অন্তত ৪টি শব্দের একটি বাক্য লেখো।'};return}
 const tips=[];
 if(!/^[A-Z]/.test(t))tips.push('বাক্য বড় হাতের অক্ষর দিয়ে শুরু করো।');
 if(!/[.!?]$/.test(t))tips.push('বাক্যের শেষে দাঁড়ি (.) দাও।');
 if(!used.length)tips.push('এই পাঠের একটি শব্দ (যেমন mango) ব্যবহার করে দেখো।');
 S.fb=tips.length?{good:false,title:'প্রায় হয়ে গেছে!',msg:tips.join(' ')}:{good:true,title:'চমৎকার লিখেছো! 🎉',msg:`তুমি ${used.join(', ')} শব্দটি ব্যবহার করেছো। (আসল অ্যাপে এআই টিউটর ব্যাকরণও দেখে দেবে।)`};
}
function act(a,d){
 switch(a){
 case 'say':say(d.t);return;
 case 'toast':toast(d.m);return;
 case 'back':return back();
 case 'tab':return go(d.k,{reset:true});
 case 'go':return go(d.s);
 case 'lesson':return go('lesson');
 case 'startvocab':S.wi=0;return go('vcard');
 case 'vprev':if(S.wi>0)S.wi--;return render();
 case 'vnext':{const w=FR[S.wi];if(!P.learned.includes(w.en)){P.learned.push(w.en);save()}if(S.wi<5){S.wi++;return render()}return launch('lesson')}
 case 'lessonq':return launch('lesson',true);
 case 'mark':{const i=P.marks.indexOf(d.w);if(i<0){P.marks.push(d.w);toast('★ সেভ করা হয়েছে')}else P.marks.splice(i,1);save();return render(true)}
 case 'vf':S.vf=d.k;return render();
 case 'search-focus':{const i=$('#vs');if(i)i.focus();return}
 case 'flash':return launch('flash');
 case 'flip':S.fl.flip=!S.fl.flip;return render(true);
 case 'flyes':case 'flno':{const z=S.fl;if(a==='flyes'){z.known++;const w=z.list[z.i];if(!P.learned.includes(w.en))P.learned.push(w.en);save()}
  if(z.i<z.list.length-1){z.i++;z.flip=false;return render()}return showRes('flash',z.known,z.list.length,z.known*2)}
 case 'gtopic':S.gt=d.k;return go('gtopic');
 case 'gprac':return launch('gq');
 case 'mcq':case 'fill':case 'daily':case 'match':return launch(a);
 case 'sent':return launch('sent');
 case 'lq':return launch('listenq');
 case 'gf':S.gf=d.k;return render();
 case 'pf':S.pf=d.k;return render();
 case 'pick':{const z=S.qz;if(z.picked!==null)return;z.picked=+d.i;if(z.picked===z.qs[z.i].ans)z.score++;return render(true)}
 case 'nextq':{const z=S.qz;if(z.i<z.qs.length-1){z.i++;z.picked=null;return render()}return finishQz()}
 case 'again':return launch(S.last==='flash'?'flash':S.last,true);
 case 'ml':{const m=S.mt;m.sel=+d.i;m.bad=null;return render(true)}
 case 'mr':{const m=S.mt;if(m.sel===null)return toast('আগে বাঁ দিক থেকে একটি শব্দ বাছো');m.moves++;
  if(m.L[m.sel]===m.R[+d.j]){m.done.push(m.L[m.sel].en);m.sel=null;m.bad=null;if(m.done.length===5)return showRes('match',Math.max(1,5-(m.moves-5)),5,Math.max(10,25-(m.moves-5)*3));return render(true)}
  m.bad=[m.sel,+d.j];m.sel=null;render(true);setTimeout(()=>{if(S.screen==='match'){S.mt.bad=null;render(true)}},600);return}
 case 'smadd':{const m=S.sm;if(m.state==='ok')return;m.chosen.push(+d.id);m.state=null;return render(true)}
 case 'smdel':{const m=S.sm;if(m.state==='ok')return;m.chosen=m.chosen.filter(x=>x!==+d.id);m.state=null;return render(true)}
 case 'smchk':{const m=S.sm;const s=m.chosen.map(id=>m.pool.find(x=>x.id===id).w).join(' ');
  if(s===m.qs[m.i][0]){m.state='ok';if(m.tries===0)m.score++}else{m.state='bad';m.tries++}return render(true)}
 case 'smnext':{const m=S.sm;if(m.i<m.qs.length-1){m.i++;smInit();return render()}return showRes('sent',m.score,m.qs.length,m.score*6)}
 case 'tog':S.open[d.i]=!S.open[d.i];return render(true);
 case 'story':return go('story');
 case 'writing':return go('writing');
 case 'check':checkWriting();return render(true);
 case 'finish':P.flags.lesson=1;addXp(20);save();return go('progress',{reset:true});
 case 'playconv':if(S.ls.play){try{speechSynthesis.cancel()}catch(e){}S.ls.play=false;return render(true)}
  S.ls.show=false;playLines(CONV);return render(true);
 case 'showtr':S.ls.show=!S.ls.show;return render(true);
 case 'mic':return mic();
 case 'spnext':S.sp={i:(S.sp.i+1)%SPS.length,state:'idle',res:null,note:''};return render(true);
 case 'spagain':S.sp.state='idle';S.sp.res=null;S.sp.note='';return render(true);
 case 'theme':{const r=document.documentElement;r.dataset.theme=isDark()?'light':'dark';P.theme=r.dataset.theme;save();return render(true)}
 case 'remind':P.remind.on=!P.remind.on;save();toast(P.remind.on?'রিমাইন্ডার চালু (ডেমোতে নোটিফিকেশন আসবে না)':'রিমাইন্ডার বন্ধ');return render(true);
 case 'goal':P.goal=+d.k;save();return render(true);
 }
}
document.addEventListener('click',e=>{const t=e.target.closest('[data-a]');if(!t)return;act(t.dataset.a,t.dataset)});
document.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.matches&&e.target.matches('.sent[data-a]')){e.preventDefault();act('tog',e.target.dataset)}});
document.addEventListener('input',e=>{
 if(e.target.id==='ta')S.text=e.target.value;
 if(e.target.id==='vs'){const q=e.target.value.toLowerCase();document.querySelectorAll('.vcard').forEach(c=>c.style.display=c.dataset.w.toLowerCase().includes(q)?'':'none')}
});
document.addEventListener('change',e=>{if(e.target.id==='rt'){P.remind.time=e.target.value;save();toast('রিমাইন্ডার সেট: '+e.target.value)}});
render();

/* PWA: অফলাইনে চালানোর জন্য */
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}))}
