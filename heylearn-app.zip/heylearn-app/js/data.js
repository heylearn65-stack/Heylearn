/* ---------- data ---------- */
const W=[
 {en:'apple',e:'🍎',ip:'/ˈæp.əl/',bn:'আপেল',pr:'অ্যাপল',c:'f',ex:'I eat an apple every day.',exb:'আমি প্রতিদিন একটি আপেল খাই।'},
 {en:'banana',e:'🍌',ip:'/bəˈnɑː.nə/',bn:'কলা',pr:'বানানা',c:'f',ex:'The banana is yellow.',exb:'কলাটি হলুদ।'},
 {en:'mango',e:'🥭',ip:'/ˈmæŋ.ɡoʊ/',bn:'আম',pr:'ম্যাঙ্গো',c:'f',ex:'Mango is my favourite fruit.',exb:'আম আমার প্রিয় ফল।'},
 {en:'orange',e:'🍊',ip:'/ˈɔːr.ɪndʒ/',bn:'কমলা',pr:'অরেঞ্জ',c:'f',ex:'She peels an orange.',exb:'সে একটি কমলা ছাড়াচ্ছে।'},
 {en:'grapes',e:'🍇',ip:'/ɡreɪps/',bn:'আঙুর',pr:'গ্রেপস',c:'f',ex:'These grapes are sweet.',exb:'এই আঙুরগুলো মিষ্টি।'},
 {en:'watermelon',e:'🍉',ip:'/ˈwɔː.tɚˌmel.ən/',bn:'তরমুজ',pr:'ওয়াটারমেলন',c:'f',ex:'We share a watermelon.',exb:'আমরা একটি তরমুজ ভাগ করে খাই।'},
 {en:'opportunity',e:'🚪',ip:'/ˌɑː.pɚˈtuː.nə.t̬i/',bn:'সুযোগ',pr:'অপরচুনিটি',c:'g',ex:'This is a great opportunity for you.',exb:'এটি তোমার জন্য দারুণ সুযোগ।'},
 {en:'improve',e:'📈',ip:'/ɪmˈpruːv/',bn:'উন্নতি করা',pr:'ইমপ্রুভ',c:'g',ex:'You should always try to improve yourself.',exb:'নিজেকে সবসময় উন্নত করার চেষ্টা করা উচিত।'},
 {en:'confidence',e:'💪',ip:'/ˈkɑːn.fə.dəns/',bn:'আত্মবিশ্বাস',pr:'কনফিডেন্স',c:'g',ex:'She speaks with confidence.',exb:'সে আত্মবিশ্বাসের সাথে কথা বলে।'},
 {en:'brave',e:'🦁',ip:'/breɪv/',bn:'সাহসী',pr:'ব্রেভ',c:'g',ex:'He is brave enough to ask questions.',exb:'সে প্রশ্ন করার মতো সাহসী।'},
 {en:'friend',e:'🤝',ip:'/frend/',bn:'বন্ধু',pr:'ফ্রেন্ড',c:'g',ex:'Mina is my best friend.',exb:'মিনা আমার সবচেয়ে ভালো বন্ধু।'},
 {en:'school',e:'🏫',ip:'/skuːl/',bn:'স্কুল',pr:'স্কুল',c:'g',ex:'We go to school by bus.',exb:'আমরা বাসে করে স্কুলে যাই।'},
 {en:'book',e:'📖',ip:'/bʊk/',bn:'বই',pr:'বুক',c:'g',ex:'This book is very interesting.',exb:'এই বইটা খুব মজার।'},
 {en:'water',e:'💧',ip:'/ˈwɑː.t̬ɚ/',bn:'পানি',pr:'ওয়াটার',c:'g',ex:'Please drink more water.',exb:'দয়া করে আরও পানি পান করো।'},
 {en:'family',e:'👨‍👩‍👧',ip:'/ˈfæm.əl.i/',bn:'পরিবার',pr:'ফ্যামিলি',c:'g',ex:'I love my family.',exb:'আমি আমার পরিবারকে ভালোবাসি।'},
 {en:'happy',e:'😊',ip:'/ˈhæp.i/',bn:'খুশি',pr:'হ্যাপি',c:'g',ex:'The children are happy today.',exb:'বাচ্চারা আজ খুশি।'}
];
const FR=W.filter(w=>w.c==='f');
const STORY=[
 ['Rumi has a small garden.','রুমির একটি ছোট বাগান আছে।'],
 ['There is a big mango tree in the garden.','বাগানে একটি বড় আমগাছ আছে।'],
 ['Every summer, the tree gives sweet mangoes.','প্রতি গ্রীষ্মে গাছটি মিষ্টি আম দেয়।'],
 ['Rumi shares the mangoes with her friends.','রুমি বন্ধুদের সাথে আম ভাগ করে খায়।'],
 ['Her friends bring a watermelon and some grapes.','তার বন্ধুরা একটি তরমুজ আর কিছু আঙুর আনে।'],
 ['Everyone is happy.','সবাই খুশি।']
];
const G=[
 {k:'tense',en:'Tense',bn:'কাল',e:'🕒',col:'blue',sub:'Present Simple',
  rule:'অভ্যাস, রুটিন আর চিরন্তন সত্য বোঝাতে Present Simple ব্যবহার হয়। He/She/It-এর সাথে verb-এর শেষে s/es বসে।',
  f:'Subject + V1 (he/she/it হলে V1 + s/es)',
  ex:[['I drink water every day.','আমি প্রতিদিন পানি পান করি।'],['She goes to school.','সে স্কুলে যায়।'],['The sun rises in the east.','সূর্য পূর্ব দিকে ওঠে।']],
  q:[['She ___ to school every day.',['goes','go','going','gone'],0],['They ___ football on Fridays.',['play','plays','playing','played'],0]]},
 {k:'pos',en:'Parts of Speech',bn:'পদ',e:'🧩',col:'green',sub:'শব্দের শ্রেণি',
  rule:'বাক্যের প্রতিটি শব্দ একটি শ্রেণির: Noun (নাম), Pronoun (সর্বনাম), Verb (কাজ), Adjective (গুণ), Adverb (কীভাবে)।',
  f:'Noun = নাম · Verb = কাজ · Adjective = গুণ · Adverb = কীভাবে',
  ex:[['The happy girl runs fast.','খুশি মেয়েটি দ্রুত দৌড়ায়। (happy = adjective, fast = adverb)'],['Mina reads a book.','মিনা একটি বই পড়ে। (reads = verb)'],['She is my friend.','সে আমার বন্ধু। (She = pronoun)']],
  q:[['"Beautiful" is a/an ___.',['adjective','noun','verb','adverb'],0],['In "Rumi sings", "sings" is a ___.',['verb','noun','pronoun','adjective'],0]]},
 {k:'art',en:'Article',bn:'আর্টিকেল',e:'🅰️',col:'yellow',sub:'a · an · the',
  rule:'a/an মানে অনির্দিষ্ট একটি কিছু। স্বরধ্বনির উচ্চারণ দিয়ে শুরু হলে an, নইলে a। নির্দিষ্ট কিছু বোঝাতে the।',
  f:'a + ব্যঞ্জন ধ্বনি · an + স্বরধ্বনি · the = নির্দিষ্ট',
  ex:[['I have a mango.','আমার একটি আম আছে।'],['She eats an apple.','সে একটি আপেল খায়।'],['The sun is hot.','সূর্য গরম।']],
  q:[['She is ___ honest girl.',['an','a','the','x'],0],['___ moon is bright tonight.',['The','A','An','x'],0]]},
 {k:'prep',en:'Preposition',bn:'প্রিপোজিশন',e:'📍',col:'purple',sub:'in · on · at',
  rule:'স্থান আর সময় বোঝাতে in, on, at ব্যবহার হয়।',
  f:'at = নির্দিষ্ট বিন্দু · on = উপরে/দিন · in = ভেতরে/মাস/বছর',
  ex:[['The book is on the table.','বইটি টেবিলের উপরে।'],['I wake up at 6 o\'clock.','আমি ৬টায় ঘুম থেকে উঠি।'],['She was born in May.','সে মে মাসে জন্মেছে।']],
  q:[['The cat is ___ the box.',['in','on','at','by'],0],['School starts ___ 8 o\'clock.',['at','in','on','to'],0]]},
 {k:'voice',en:'Voice',bn:'বাচ্য',e:'🔄',col:'blue',sub:'Active · Passive',
  rule:'কর্তা কাজ করলে Active। কাজটি কর্তার উপর হলে Passive।',
  f:'Passive: Object + be + V3 + by Subject',
  ex:[['Rumi writes a letter.','রুমি একটি চিঠি লেখে। (Active)'],['A letter is written by Rumi.','চিঠিটি রুমির দ্বারা লেখা হয়। (Passive)'],['The boy ate the cake.','ছেলেটি কেকটি খেল। (Active)']],
  q:[['A letter ___ by Rumi.',['is written','writes','wrote','is writing'],0],['Which one is passive?',['Rice is eaten by him.','He eats rice.','He ate rice.','He is eating rice.'],0]]},
 {k:'narr',en:'Narration',bn:'উক্তি',e:'💬',col:'green',sub:'Direct · Indirect',
  rule:'কারো কথা হুবহু বললে Direct। নিজের ভাষায় বললে Indirect, তখন tense সাধারণত এক ধাপ পিছিয়ে যায়।',
  f:'He said, "I am happy." → He said that he was happy.',
  ex:[['She said, "I like mango."','সে বলল, "আমি আম পছন্দ করি।" (Direct)'],['She said that she liked mango.','সে বলল যে সে আম পছন্দ করে। (Indirect)'],['He said that he was tired.','সে বলল যে সে ক্লান্ত।']],
  q:[['He said, "I am tired." → He said that he ___ tired.',['was','is','were','be'],0],['She said, "I like mango." → She said that she ___ mango.',['liked','likes','like','liking'],0]]}
];
const FILL=[
 ['I ___ a student.',['am','is','are','be']],['She ___ an apple every day.',['eats','eat','eating','ate']],
 ['They ___ playing in the park.',['are','is','am','was']],['The sky ___ blue.',['is','are','am','be']],
 ['We ___ to school by bus.',['go','goes','going','gone']],['He ___ a doctor.',['is','am','are','were']]
];
const SM=[['I like sweet mangoes','আমি মিষ্টি আম পছন্দ করি'],['She drinks water every day','সে প্রতিদিন পানি পান করে'],['We go to school together','আমরা একসাথে স্কুলে যাই'],['My friend is very brave','আমার বন্ধু খুব সাহসী'],['The banana is yellow','কলাটি হলুদ']];
const CONV=[{n:'Mina',t:'Hi Rafi! Where are you going?',p:1.3},{n:'Rafi',t:'Hi Mina. I am going to the market to buy some fruits.',p:.8},{n:'Mina',t:'Great! Can I come with you?',p:1.3},{n:'Rafi',t:'Sure! Let us go together.',p:.8}];
const LQ=[['Where is Rafi going?',['To the market','To school','To the park','To the library'],0],['What does Rafi want to buy?',['Fruits','Books','Shoes','Water'],0],['What does Mina ask Rafi?',['If she can come along','For some money','For a book','For the way'],0]];
const SPS=['I am learning English.','Nice to meet you.','I like sweet mangoes.','Can you help me, please?','Water is very important.'];
const LV=[
 {en:'Beginner',bn:'শুরুর স্তর',ic:'🌱',min:0,d:'ইংরেজি শেখার যাত্রা শুরু',col:'green'},
 {en:'Elementary',bn:'প্রাথমিক',ic:'🌿',min:500,d:'ভিত্তি মজবুত করো',col:'blue'},
 {en:'Intermediate',bn:'মাঝারি',ic:'🌳',min:1500,d:'আত্মবিশ্বাসের সাথে বলো',col:'purple'},
 {en:'Advanced',bn:'উন্নত',ic:'👑',min:3000,d:'ইংরেজিতে দক্ষ হও',col:'yellow'}
];
const UNITS=[['🍎','ফল','Fruits','৬টি শব্দ','blue'],['👨‍👩‍👧','পরিবার','Family','৮টি শব্দ','green'],['🏫','স্কুল','School','১০টি শব্দ','yellow'],['🍚','খাবার','Food','৯টি শব্দ','purple'],['⏰','দিনের রুটিন','Daily Routine','৮টি শব্দ','blue']];
const BADGES=[['🥇','প্রথম পাঠ','একটি পাঠ শেষ করো','lesson'],['🔥','৭ দিনের স্ট্রিক','টানা ৭ দিন শেখো','streak'],['📚','১০টি শব্দ','১০টি শব্দ শেখো','words'],['🎯','কুইজ মাস্টার','MCQ-তে পুরো নম্বর','quiz'],['🎙️','ভালো বক্তা','স্পিকিংয়ে ৮০+ পাও','speak'],['🎧','মনোযোগী শ্রোতা','শোনার প্রশ্নে ভালো করো','listen'],['🏆','ডেইলি চ্যালেঞ্জ','আজকের চ্যালেঞ্জ শেষ করো','daily'],['✏️','ব্যাকরণ শিক্ষার্থী','৩টি ব্যাকরণ বিষয় শেষ করো','gram']];

/* ---------- state ---------- */
const store={get(){try{return JSON.parse(localStorage.getItem('heylearn')||'{}')}catch(e){return{}}},set(o){try{localStorage.setItem('heylearn',JSON.stringify(o))}catch(e){}}};
const P=Object.assign({xp:210,learned:['apple','banana','friend','school','book','water'],marks:[],gdone:[],flags:{},remind:{on:true,time:'20:00'},goal:15,theme:null,speak:32,listen:28},store.get());
const save=()=>store.set(P);
const S={screen:'splash',stack:[],wi:0,vf:'all',gf:'all',pf:'overview',lscore:0,open:{},text:'',fb:null,gt:'tense',ls:{show:false,play:false},sp:{i:0,state:'idle',res:null,note:''}};
if(P.theme)document.documentElement.dataset.theme=P.theme;
