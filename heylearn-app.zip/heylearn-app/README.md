# HeyLearn 📘
বাংলাভাষী শিক্ষার্থীদের জন্য ইংরেজি শেখার অ্যাপ (PWA — ফোনে ইনস্টল করা যায়, অফলাইনেও চলে)।

## ফোল্ডার
- `index.html` — অ্যাপের পেজ
- `css/style.css` — ডিজাইন (রং, কার্ড, ডার্ক মোড)
- `js/data.js` — **সব কনটেন্ট** (শব্দ, ব্যাকরণ, গল্প, কুইজ)। নতুন পাঠ এখানেই যোগ করুন
- `js/app.js` — স্ক্রিন ও লজিক
- `sw.js` — অফলাইন ক্যাশ (কোড বদলালে `VERSION` বাড়ান)
- `manifest.webmanifest`, `icons/` — "Add to Home screen"-এর জন্য

## চালানো (GitHub Pages)
1. GitHub-এ নতুন repo বানান (নাম: `heylearn`), এই ফোল্ডারের সব ফাইল আপলোড করুন।
2. Settings → Pages → Branch: `main` / root → Save।
3. ১–২ মিনিট পর `https://<আপনার-ইউজারনেম>.github.io/heylearn/` লিংকে অ্যাপ খুলবে।
4. ফোনের Chrome-এ খুলে মেনু → "Add to Home screen"।

## লোকালি দেখা
`python3 -m http.server 8000` চালিয়ে ব্রাউজারে `localhost:8000` খুলুন।
(ফাইলে ডাবল ক্লিক করলে অফলাইন ক্যাশ কাজ করবে না, সার্ভার লাগবে।)

## পরের ধাপ
- নতুন পাঠ: `js/data.js`-এ শব্দ যোগ করুন
- লগইন ও ক্লাউডে অগ্রগতি সেভ: Supabase বা Firebase
- Play Store-এর জন্য APK: Capacitor দিয়ে এই ফোল্ডারটাই মুড়িয়ে নেওয়া যায়
